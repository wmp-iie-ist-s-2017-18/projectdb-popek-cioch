package Kontrolery;

import javafx.fxml.FXML;

public class KontrolerOkna3 {

	private KontrolerOkna1 kontrolerOkna1;
	@FXML
	public void back() {
		
		kontrolerOkna1.loadScreen();
		
	
}
	
	public void dodaj() {
	  
	      
		
	}
	public void setKontrolerOkna1(KontrolerOkna1 kontrolerOkna1) {
		this.kontrolerOkna1 = kontrolerOkna1;
	}
	
}